import { AppRoutingModule } from './app-routing.module';

@NgModule({
  // ...
  imports: [
    // existentes
    AppRoutingModule
  ]
})